import { TestBed } from '@angular/core/testing';

import { LoanEmiServiceService } from './loan-emi-service.service';

describe('LoanEmiServiceService', () => {
  let service: LoanEmiServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoanEmiServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
