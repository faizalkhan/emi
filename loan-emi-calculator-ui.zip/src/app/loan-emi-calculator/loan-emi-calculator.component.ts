import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder, AbstractControl, } from '@angular/forms';
import { AgChartThemeOverrides, ColDef, GridApi, GridOptions, IAggFunc, IAggFuncParams, RowGroupingDisplayType } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-balham.css';
import 'ag-grid-enterprise';
import { LoanEmiServiceService } from './services/loan-emi-service.service';
import { APIMapper } from '../helper/utility';
import { Helper } from '../helper/helper';
import { AgChartOptions, AgCharts } from 'ag-charts-community';
import {
  AgBarSeriesOptions, AgCartesianAxisOptions, AgCartesianChartOptions, AgCartesianSeriesOptions,
  AgCartesianSeriesTooltipRendererParams, AgLineSeriesOptions,
} from 'ag-grid-enterprise/dist/lib/chart/agChartOptions';
import { AgGridAngular } from 'ag-grid-angular';
import { Message } from 'primeng/api';
import { WebAccessibilityService } from '../helper/web-accessibility.service';

declare var moment: any;
declare var $: any;
interface ChartOptionBase { label: string; value: string; }

interface ChartOptionWithNavigator extends ChartOptionBase {
  navigator: { enabled: boolean; height: number; series: { type: string } };
}

@Component({
  selector: 'cync-loan-emi-calculator',
  templateUrl: './loan-emi-calculator.component.html',
  styleUrls: ['./loan-emi-calculator.component.scss'],
})

export class LoanEmiCalculatorComponent implements OnInit, AfterViewInit {
  isLoading = false;
  calculateButtonDisabled = true;
  options!: AgChartOptions;
  options1: AgCartesianChartOptions | any;
  options2: AgCartesianChartOptions | any;
  selectedDate: Date | undefined;
  @ViewChild('loandAmountRange') inputloandAmountRange!: ElementRef<HTMLInputElement>;
  @ViewChild('loanInterestRate') inputloanRateRange!: ElementRef<HTMLInputElement>;
  @ViewChild('loanTermLoanRange') inputloanTermRange!: ElementRef<HTMLInputElement>;
  @ViewChild('agGrid', { static: false }) agGrid: AgGridAngular | undefined;
  @ViewChild('ogDate') ogDate!: ElementRef<HTMLInputElement>;
  date3: Date | undefined;
  rowData: any;
  finalPaymentDate: any;
  originationDate: any;
  firstEmiDate = moment(new Date()).add(1, 'M');
  result: any;
  orinationSelecteDate!: string;
  periodList: any;
  periodListSelected: any = [];
  loanForm!: FormGroup;
  private api: GridApi | any;
  isDisabled = true;
  interestRates = [];
  disbursements = [];
  paymentDues = [];
  displayYearChart = true;
  isPeriodDisabled = false;
  isYearDisabled = false;
  loanAmountvalue: any;
  disbursAmountVal: any;
  loanAmountRange = 100000;
  loanAmount: any;
  monthlyEmi: any;
  totalInterestAmount: any;
  totalOutStandingBalance: any;
  msgs: Message[] | any;
  intPie: any;
  chartOptions: { label: string; value: string }[] = [];
  selectedChart = '';
  sliderValue = 100;
  showFixedPrincipalInput = false;
  calculatedValue: number | undefined;
  public fixedPrincipalTxtBox = '';
  public groupDisplayType: RowGroupingDisplayType = 'multipleColumns';
  addItemDisb = true;
  data = {
    interest: [
      {
        effectiveDate: new Date().toISOString().substring(0, 10),
        interestRate: 8,
      },
    ],
  };
  data1 = {
    disbursements: [
      {
        disbursementDate: new Date().toISOString().substring(0, 10),
        amount: '100000',
      },
    ],
  };
  data2 = {
    paymentDues: [
      {
        period: '0',
        amount: 'Full Amount',
      },
    ],
  };
  params: any;
  mappedIntrest = 10;
  minDate: string | undefined;
  minDateOrigin!: string;
  initialTextBoxValue: any;
  isEditedFixedInstallment = false;
  isEditedFixedPrincipal = false;
  showTextBox = false;
  errorMessage: string | undefined;
  disbursementDateMinValidator: any = [null];
  minDateDis: any;

  printPage(): void {
    window.print();
  }

  constructor(
    private formBuilder: FormBuilder,
    private httpclient: HttpClient,
    private loanEmiService: LoanEmiServiceService,
    private _apiMapper: APIMapper,
    private helper: Helper,
    private elementRef: ElementRef,
    private webAccService: WebAccessibilityService,

  ) {
    this.isLoading = true;
    const initialLoanAmount = '100000';
    const formattedLoanAmount = this.formatCurrency(initialLoanAmount);
    this.loanForm = this.formBuilder.group({
      loanAmount: [formattedLoanAmount, Validators.required],
      interestRate: ['8', [Validators.required, Validators.max(30)]],
      initialPaymentDate: [],
      interestEffectiveDate: [],
      loanTerm: ['12'],
      interestCalc: ['30/360'],
      amortizationMethod: ['normal'],
      interestRates: this.formBuilder.array([]),
      disbursements: this.formBuilder.array([]),
      paymentDues: this.formBuilder.array([]),
      textBoxValue: ['0'],
    });
    this.setMinDate();
    this.setMinDateOrigin();
    this.setCompanies();
    this.setCompanies1();
    this.setCompanies2();
    this.orinationSelecteDate = new Date().toISOString().substring(0, 10);

    this.options = {
      data: [],
      series: [
        {
          type: 'pie',
          sectorLabelKey: 'amount',
          angleKey: 'amount',
          legendItemKey: 'asset',
          innerRadiusRatio: 0.5,
          sectorLabel: {
            formatter: function (params) {
              return `${params.value}%`;
            },
          },
          tooltip: {
            renderer: function (params) {
              if (params.datum.asset === 'Interest') {
                return `<div class="bg-red" style="background-color:white; height:20px; padding :10px;height:40px" > Total Interest  : ${params.datum.amount}% </div>`;
              } else {
                return `<div class="bg-red" style="background-color:white; height:20px; padding :10px;height:40px"> Prinicipal Amount   : ${params.datum.amount}% </div>`;
              }
            },
          },
        },
      ],
    };
    this.options1 = {
      data: [],
      series: BAR_AND_LINE,
      axes: [
        {
          type: 'category',
          position: 'bottom',
        },
        {
          // primary y axis
          type: 'number',
          position: 'left',
          keys: ['regularInterest', 'regularPrincipal'],
          label: {
            formatter: (params) => {
              return this.formatLargeNumber(params.value);
            },
          },
        },
        {
          // secondary y axis
          type: 'number',
          position: 'right',
          title: {
            text: 'Balance',
          },
          keys: ['endingBalance'],

          label: {
            formatter: (params) => {
              return this.formatLargeNumber(params.value);
            },
          },
        },
      ] as AgCartesianAxisOptions[],
    };

    //option2
    this.options2 = {
      data: [],
      series: BAR_AND_LINE1,
      axes: [
        {
          type: 'category',
          position: 'bottom',
        },
        {
          // primary y axis
          type: 'number',
          position: 'left',
          keys: ['regularInterest', 'regularPrincipal'],
          label: {
            formatter: (params) => {
              return this.formatLargeNumber(params.value);
            },
          },
        },
        {
          // secondary y axis
          type: 'number',
          title: {
            text: 'Balance',
          },
          position: 'right',
          keys: ['endingBalance'],
          label: {
            formatter: (params) => {
              return this.formatLargeNumber(params.value);
            },
          },
        },
      ] as AgCartesianAxisOptions[],
    };
    this.selectedChart = 'period';
  }

  public ngOnInit(): void {
    this.loanForm.value.interestRates[0].interestRate = 8;
    this.getDataa('load');
    this.getOriginationDate();
    this.InitialFormBinding();
    this.chartOptions = [
      {
        label: 'Year',
        value: 'year',
      },
      {
        label: 'Period',
        value: 'period',
      },
    ];
    this.selectedChart = 'period'; // Set default value 'period'
    this.initialTextBoxValue = this.formatCurrency(this.loanForm.get('textBoxValue')?.value);
  }


  ngAfterViewInit() {

    this.webAccService.accesibiltyValidation(this.elementRef.nativeElement, 'ag-grid');
    this.webAccService.accesibiltyValidation(this.elementRef.nativeElement, 'p-selectbutton');

    if (this.agGrid) {
      const gridApi = this.agGrid.api;
      const domLayout = 'autoHeight';
      gridApi.setDomLayout(domLayout);
    }
    this.adjustHeaderSticky();
  }


  onControlSelected(isView: boolean) {
    const selectedControlValue = this.loanForm?.get('amortizationMethod')?.value;

    if (selectedControlValue === 'fixedPrincipal' || selectedControlValue === 'fixedInstallment') {
      this.showTextBox = true;

      if (selectedControlValue === 'fixedPrincipal') {

        this.subscribeToTextBoxChanges();

        //this.onTextBoxValueChanged()

        this.prepareAndCallAPI(`${this._apiMapper.endpoints}/calculate-fixed-principal?`, isView);
      }

      else if (selectedControlValue === 'fixedInstallment') {

        this.prepareAndCallAPI(`${this._apiMapper.endpoints}/calculate-fixed-installment?`, isView);
      }
    } else {
      this.resetTextBoxAndHide();
    }
  }

  subscribeToTextBoxChanges() {
    this.loanForm.get('textBoxValue')?.valueChanges.subscribe((newValue) => {
      const currentTextBoxValue = newValue;
      if (!this.isEditedFixedInstallment && currentTextBoxValue !== this.initialTextBoxValue) {
        this.isEditedFixedInstallment = true;
      }
      if (!this.isEditedFixedPrincipal && currentTextBoxValue !== this.initialTextBoxValue) {
        this.isEditedFixedPrincipal = true;
      }
    });
  }

  cachedData: Map<string, any> = new Map<string, any>();

  onTextBoxValueChanged(event: Event, isEdit: boolean) {

    const keyboardEvent = event as KeyboardEvent;
    if (keyboardEvent.key === 'Enter' || keyboardEvent.type === 'change') {
      const currentTextBoxValue = this.loanForm?.get('textBoxValue')?.value;
      const selectedControlValue = this.loanForm?.get('amortizationMethod')?.value;


      // Fetch data from API
      if (selectedControlValue === 'fixedPrincipal') {
        this.prepareAndCallAPI(`${this._apiMapper.endpoints}/calculate-fixed-principal?`, isEdit);
        this.calculateButtonDisabled = false;
      } else if (selectedControlValue === 'fixedInstallment') {
        this.prepareAndCallAPI(`${this._apiMapper.endpoints}/calculate-fixed-installment?`, isEdit);
      }


      // const cachedKey = `${selectedControlValue}_${currentTextBoxValue}`;
      // const cachedValue = this.cachedData.get(cachedKey);

      // if (cachedValue) {
      // } else {
      //   // Fetch data from API
      //   if (selectedControlValue === 'fixedPrincipal') {
      //     this.prepareAndCallAPI(`${this._apiMapper.endpoints}/calculate-fixed-principal?`, isEdit);
      //     this.calculateButtonDisabled = true;
      //   } else if (selectedControlValue === 'fixedInstallment') {
      //     this.prepareAndCallAPI(`${this._apiMapper.endpoints}/calculate-fixed-installment?`, isEdit);
      //   }

      // }
    }

  }



  prepareAndCallAPI(apiUrl: string, isEdit?: boolean) {

    const selectedControlValue = this.loanForm?.get('amortizationMethod')?.value;

    //let fixedPrnEditable = true;
    if (selectedControlValue === 'fixedPrincipal') {

      let obj: any = {
        principalAmount: Number(this.loanForm?.get('loanAmount')?.value.replace(/[^0-9.-]+/g, '')),
        terms: this.loanForm?.get('loanTerm')?.value,
        isEditedFixedPrincipal: isEdit ? true : false,
        fixedPrincipal: isEdit ? Number(this.loanForm?.get('textBoxValue')?.value.replace(/[^0-9.-]+/g, '')) : 0
      };
      this.callAPIService(apiUrl, obj, selectedControlValue);
    }

    // fixedPrnEditable = false;
    if (selectedControlValue === 'fixedInstallment') {

      // let fixedInstEditable = true;
      let obj = {
        principalAmount: Number(
          this.loanForm?.get('loanAmount')?.value.replace(/[^0-9.-]+/g, '')
        ),
        terms: this.loanForm?.get('loanTerm')?.value,
        termType: 'months',
        originationDate: this.orinationSelecteDate
          ? new Date(this.orinationSelecteDate)?.toLocaleDateString('en-US', {
            month: '2-digit',
            day: '2-digit',
            year: 'numeric',
          })
          : '',
        initialPaymentDate: this.firstEmiDate
          ? new Date(this.firstEmiDate)?.toLocaleDateString('en-US', {
            month: '2-digit',
            day: '2-digit',
            year: 'numeric',
          })
          : '',
        intCalcDay: '30',
        yearDivisor: '360',
        interestRate: this.loanForm.controls['interestRate'].value,
        fixedInstallment: isEdit ? this.loanForm?.get('textBoxValue')?.value.replace(/[^0-9.-]+/g, '') : 0,
        isEditedFixedInstallment: isEdit ? true : false
      }
      // fixedInstEditable = false;
      const interestCalcValue = this.loanForm.get('interestCalc')?.value;

      if (interestCalcValue.includes('/')) {
        const [intCalcDayValue, yearDivisorValue] = interestCalcValue.split('/');

        if (intCalcDayValue) {
          obj.intCalcDay = intCalcDayValue.trim() === 'Actual' ? 'actuals' : intCalcDayValue.trim();
        }

        if (yearDivisorValue) {
          obj.yearDivisor = yearDivisorValue.trim() === 'Actual' ? 'actuals' : yearDivisorValue.trim();
        }
      }

      this.callAPIService(apiUrl, obj, selectedControlValue);

    }

  }

  callAPIService(apiUrl: string, obj: any, selectedControlValue: string) {
    const serviceMethod = selectedControlValue === 'fixedPrincipal' ? 'getServiceAmoz1' : 'getServiceAmoz';
    this.loanEmiService[serviceMethod](apiUrl, obj).subscribe({
      next: (data) => {
        this.handleAPISuccess(data, selectedControlValue);
      },
      error: (err) => {
        this.isLoading = false;
        this.loanEmiService.setMsg({
          message: `${err.error.message}`,
          msg_type: 'error',
        });
      },
    });
  }
  onFixedPrincipalTxtBoxChange(newValue: any) {
    this.isEditedFixedInstallment = true;

  }
  handleAPISuccess(data: any, selectedControlValue: string) {
    // debugger
    if (selectedControlValue === 'fixedPrincipal') {
      this.loanForm?.get('textBoxValue')?.setValue(this.formatCurrency(data));
      this.getDataa('load');
      if (!this.isEditedFixedInstallment) {
        this.fixedPrincipalTxtBox = this.formatCurrencyDisbersment(data);
      }
    } else if (selectedControlValue === 'fixedInstallment') {
      this.loanForm?.get('textBoxValue')?.setValue(this.formatCurrency(data));
      this.getDataa('load');

      if (!this.isEditedFixedInstallment) {
        this.fixedPrincipalTxtBox = this.formatCurrencyDisbersment(data);
      }
    }

  }

  resetTextBoxAndHide() {
    this.loanForm?.get('textBoxValue')?.setValue(0);
    this.showTextBox = false;
  }
  // Custom function to format currency
  formatCurrency(value: string): string {
    if (!value) return value;

    const number = parseFloat(value).toFixed(2);
    return number.replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
  }

  //chart formating function
  formatLargeNumber(value: number): string {
    if (value < 0) {
      return value.toString();
    }
    const suffixes = ['', 'K', 'M', 'B', 'T'];
    const tier = (Math.log10(Math.abs(value)) / 3) | 0;
    if (tier === 0) return value.toString();
    if (tier === 1) {
      const scaledValue = value / 1000;
      const formattedValue = scaledValue;
      return `${formattedValue}K`;
    }
    const suffix = suffixes[tier];
    const scale = Math.pow(10, tier * 3);
    const scaledValue = value / scale;
    const formattedValue = scaledValue;
    return `${formattedValue}${suffix}`;
  }

  //dispursement formatting functions
  formatCurrencyDisbersment(value: string): string {
    if (!value) return value;
    const number = parseFloat(value).toFixed(2);
    const parts = number.toString().split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
  }


  adjustHeaderSticky() {
    const container = this.elementRef.nativeElement.querySelector('#wrapper');
    const header = this.elementRef.nativeElement.querySelector('.ag-header');

    if (container && header) {
      if (container.scrollHeight > container.clientHeight) {
        header.style.position = 'sticky';
        header.style.top = '0';
        header.style.zIndex = '999999999999';
      } else {
        header.style.position = '';
        header.style.top = '';
        header.style.zIndex = '';
      }
    }
  }

  handleInput(event: Event, controlName: string): void {
    const inputElement = event.target as HTMLInputElement;
    let inputValue = inputElement.value;
    // Replace non-numeric characters
    inputValue = inputValue.replace(/[^0-9.]/g, '');

    // Update the form control value
    this.loanForm.patchValue({
      [controlName]: inputValue,
    });
  }
  validateNumber(event: KeyboardEvent): void {
    const allowedKeys = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const keyPressed = event.key;

    if (!allowedKeys.includes(keyPressed)) {
      event.preventDefault();
    }
  }
  validateNumberPayment(event: KeyboardEvent): void {
    const allowedKeys = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'];
    const keyPressed = event.key;

    // Check if the pressed key is a valid digit or decimal point
    if (!allowedKeys.includes(keyPressed)) {
      event.preventDefault();
    }

    // Check if there is already a decimal point in the input
    const inputValue = (event.target as HTMLInputElement).value;
    const decimalCount = inputValue.split('.').length - 1;

    if (decimalCount > 0 && keyPressed === '.') {
      event.preventDefault();
    }
  }

  manulpulatePiCart(formatDate: any) {
    this.options = {
      ...this.options,
      data: formatDate,
    };
  }

  chartAction(event: any): void {
    // this.selectedChart = event.value;
  }

  getArrayControls() {
    return (<FormArray>this.loanForm.get('interestRates')).controls;
  }
  getArrayControls1() {
    return (<FormArray>this.loanForm.get('disbursements')).controls;
  }
  getArrayControls2() {
    return (<FormArray>this.loanForm.get('paymentDues')).controls;
  }

  // Advance Calculations interestRates
  createItem(): FormGroup {
    return this.formBuilder.group({
      effectiveDate: '',
      interestRate: '', // Set initial disabled state
    });
  }

  addItem(): void {
    let interestRates = <FormArray>this.loanForm.controls['interestRates'];
    interestRates.push(this.createItem());
  }

  deleteItem(): void {
    let items = <FormArray>this.loanForm.controls['interestRates'];
    if (items.length > 1) {
      items.removeAt(items.length - 1);
    }
  }
  setCompanies() {
    let control = <FormArray>this.loanForm.controls['interestRates'];
    this.data.interest.forEach((x) => {
      control.push(
        this.formBuilder.group({
          effectiveDate: x.effectiveDate,
          interestRate: x.interestRate,
        })
      );
    });
  }

  // Advance Calculations disbursements
  createItem1(itemValue: any, currentIndex: number): FormGroup {
    this.disbursementMinDateHandler(currentIndex);
    const t = this.formBuilder.group({
      disbursementDate: new FormControl(''),
      amount: itemValue ? itemValue : '0',
    });
    return t;
  }

  disbursementMinDateHandler(currentIndex: number) {
    if (currentIndex === 0) {
      return;
    }
    let controlTemp = (<FormArray>this.loanForm.controls['disbursements']).controls;

    for (let i = currentIndex; i <= controlTemp.length; i++) {
      const disValue: string = controlTemp.at(i - 1)?.get('disbursementDate')?.value;
      const tempDate = new Date(disValue)
      tempDate.setDate(tempDate.getDate() + 1);
      tempDate.toISOString().substring(0, 10)
      const momentDate = moment(tempDate);
      if (this.disbursementDateMinValidator[i]) {
        this.disbursementDateMinValidator[i] = momentDate.toISOString().substring(0, 10);
      } else {
        this.disbursementDateMinValidator.push(momentDate.toISOString().substring(0, 10));
      }
      controlTemp.at(i + 1)?.get('disbursementDate')?.setValue(null);
    }

  }
  itemvalues: any;
  isDisabledItem = false;


  changeDate(control: AbstractControl, currentIndex: any) {
    this.minDateDis = control?.value.disbursementDate;


    this.calculateButtonDisabled = false; // Disable if interestCalcValue is null or undefined
  }

  addItem1(item: any, add = true): void {

    this.itemvalues = Number(item.amount.replace(/[^0-9.-]+/g, ''));
    if (this.itemvalues === 0) {
      this.isDisabledItem = true;
      return
    }

    let items = <FormArray>this.loanForm.controls['disbursements'];
    const loanAmount = Number(this.loanForm.controls['loanAmount'].value.replace(/[^0-9.-]+/g, ''));
    const disbursementAmount = Number(items.value[0].amount.replace(/[^0-9.-]+/g, ''));
    const totalValue = items.value.reduce((total: any, x: any) => {
      const amount = Number(x.amount.replace(/[^0-9.-]+/g, ''));
      return total - amount;
    }, Number(this.loanForm.controls['loanAmount'].value.replace(/[^0-9.-]+/g, '')));


    if (totalValue >= 0) {
      if (items.length !== 0) {
        if (totalValue !== 0) {
          items.push(this.createItem1(this.formatCurrency(totalValue.toString()), items.length));
        }
      }
    } else {

      this.isLoading = false;
      this.loanEmiService.setMsg({
        message: `Please Enter Disbursement Amount lesser than Loan Amount`,
        msg_type: 'error',
      });
    }
  }

  deleteItem1(): void {
    let items = <FormArray>this.loanForm.controls['disbursements'];
    if (items.length > 1) {
      items.removeAt(items.length - 1);
      // this.addItem1(false);

    }
  }
  setCompanies1() {
    let control = <FormArray>this.loanForm.controls['disbursements'];
    this.data1.disbursements.forEach((x) => {
      control.push(
        this.formBuilder.group({
          disbursementDate: x.disbursementDate,
          amount: this.formatCurrency(x.amount),
        })
      );
    });
  }
  // Advance Calculations paymentDues

  createItem2(): FormGroup {
    return this.formBuilder.group({
      period: '0',
      amount: 'Full Amount',
    });
  }

  addItem2(): void {

    let items = <FormArray>this.loanForm.controls['paymentDues'];
    // items.push(this.createItem2());
    if (items.length !== 0) {

      items.push(this.createItem2())

    }
  }
  deleteItem2(): void {
    let items = <FormArray>this.loanForm.controls['paymentDues'];
    if (items.length > 1) {
      items.removeAt(items.length - 1);
    }
  }

  setCompanies2() {
    let control = <FormArray>this.loanForm.controls['paymentDues'];
    this.data2.paymentDues.forEach((x) => {
      control.push(
        this.formBuilder.group({
          period: x.period,
          amount: x.amount,
        })
      );
    });
  }

  InitialFormBinding() {
    //interestRates binding
    let interestRates = <FormArray>this.loanForm.controls['interestRates'];
    interestRates.at(0).get('interestRate')?.disable();
    interestRates.at(0).get('effectiveDate')?.disable();

    //interest rate binding to text field in interest rates
    interestRates.at(0).get('interestRate')?.setValue(this.loanForm.controls['interestRate'].value);
    let disbursements = <FormArray>this.loanForm.controls['disbursements'];

    // Get the loan amount from the form
    const loanAmountValue = this.loanForm.controls['loanAmount'].value;
    // Set the formatted loan amount to the disbursements amount control
    disbursements.at(0).get('amount')?.setValue(loanAmountValue);

    // Disable the disbursementDate control
    disbursements.at(0).get('disbursementDate')?.disable();

    //period drop down loop using loan term
    const periodRange = (start: number, end: number) =>
      Array.from({ length: end - start }, (v, k) => k + start);
    this.periodList = periodRange(1, this.loanForm.controls['loanTerm'].value);
  }

  onPeriodFldChange(e: any, i: number) {

    if (i == 0) {
      this.periodListSelected = e.target.value;
    }
    if (e.target.value == 0) {
      this.loanEmiService.setMsg({
        message: `Please select Payment Period`,
        msg_type: 'error',
      });
    }
    else {
      this.periodListSelected = this.periodListSelected < e.target.value ? e.target.value : this.periodListSelected
    }

  }

  periodDisabledFunction(item: any, i: number) {


    if (i === 0) {
      return ['x', 'y', 'z'].includes(item)
    }
    else {
      var foo = [];
      for (var i = 1; i <= this.periodListSelected; i++) {
        foo.push(i);
      }

    }
    return foo.includes(item);


  }


  // loan Amount slider ranges
  loanAmountRangeAction(rangValue: string): void {
    let rangValueInt = parseInt(rangValue, 10);
    let slider = document.querySelector("#your-nameRange");

    if (rangValueInt >= 500000) {
      slider?.setAttribute("min", '250000');
      slider?.setAttribute("max", '10000000');
    }
    if (rangValueInt >= 5000000) {
      slider?.setAttribute("min", '2500000');
      slider?.setAttribute("max", '100000000');
    }
    if (rangValueInt >= 50000000) {
      slider?.setAttribute("min", '25000000');
      slider?.setAttribute("max", '1000000000');
    }
    if (rangValueInt >= 500000000) {
      slider?.setAttribute("min", '250000000');
      slider?.setAttribute("max", '10000000000');
    }

    // if(rangValueInt == 1000000){
    //   slider?.setAttribute("min", '1000000');
    //   slider?.setAttribute("max", '10000000');
    // }
    // if(rangValueInt == 10000000){
    //   slider?.setAttribute("min", '10000000');
    //   slider?.setAttribute("max", '100000000');
    // }
    // if(rangValueInt == 100000000){
    //   slider?.setAttribute("min", '100000000');
    //   slider?.setAttribute("max", '1000000000');
    // }
    // if(rangValueInt == 1000000000){
    //   slider?.setAttribute("min", '1000000000');
    //   slider?.setAttribute("max", '10000000000');
    // }


    // let calculateLoanAMount = this.calculatePercentLoanAmount(+rangValue);
    this.loanForm.controls['loanAmount'].patchValue(rangValue);
    let amountEnter = this.loanForm.controls['loanAmount'].value;
    amountEnter = Number(amountEnter.replace(/[^0-9.-]+/g, ''));
    let USDollar = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    });

    let amountEnterInput = USDollar.format(amountEnter).replace('$', '');
    this.loanAmountRange = amountEnter;
    this.loanAmountvalue = amountEnterInput;
    //disbursement amount binding of loan amount
    let disbursements = <FormArray>this.loanForm.controls['disbursements'];
    let disbursementAmountFormat = this.formatCurrencyDisbersment(
      this.loanForm.controls['loanAmount'].value
    );

    disbursements.at(0).get('amount')?.setValue(disbursementAmountFormat);
    this.resetForm();

    this.getDataa('load');
  }

  // loan Amount Field Binding

  disbursAmountValChange(item: any, index: any): void {
    const disbursements = <FormArray>this.loanForm.controls['disbursements'];

    const disbursementControl = disbursements.at(index).get('amount');
    if (!disbursementControl) return;
    let disbursementsAmt = disbursementControl.getRawValue();
    disbursementsAmt = Number(disbursementsAmt.replace(/[^0-9.-]+/g, ''));
    const USDollar = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    });
    const disbursementsAmtInput = USDollar.format(disbursementsAmt).replace('$', '');

    // Update the value for the specific field
    disbursementControl.setValue(disbursementsAmtInput);
    this.addItem1(item.value, false);
  }



  onLoanAmountEnter() {
    let rangValue = +this.loanForm.controls['loanAmount'].value;
    let rangValueInt = rangValue;
    let slider = document.querySelector("#your-nameRange");


    if (rangValueInt < 1000000) {
      slider?.setAttribute("min", '100000');
      slider?.setAttribute("max", '1000000');
    }
    if (rangValueInt >= 1000000 && rangValueInt < 10000000) {
      slider?.setAttribute("min", '1000000');
      slider?.setAttribute("max", '10000000');
    }
    if (rangValueInt >= 10000000 && rangValueInt < 100000000) {
      slider?.setAttribute("min", '10000000');
      slider?.setAttribute("max", '100000000');
    }
    if (rangValueInt >= 100000000 && rangValueInt < 1000000000) {
      slider?.setAttribute("min", '100000000');
      slider?.setAttribute("max", '1000000000');
    }

    // this.loanForm.controls['loanAmount'].patchValue(calculateLoanAMount);

    let amountEnter = this.loanForm.controls['loanAmount'].value;
    amountEnter = Number(amountEnter.replace(/[^0-9.-]+/g, ''));

    let USDollar = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    });
    let amountEnterInput = USDollar.format(amountEnter).replace('$', '');

    this.loanAmountvalue = amountEnterInput;

    if (this.loanAmountvalue < 1) {
      this.loanEmiService.setMsg({
        message: `Principal amount cannot be 0.`,
        msg_type: 'error',
      });
      return;
    }

    this.loanAmountRange = rangValue;
    // Disbursement amount binding of loan amount
    let disbursements = <FormArray>this.loanForm.controls['disbursements'];
    let disbursementAmountFormat = this.formatCurrencyDisbersment(
      this.loanForm.controls['loanAmount'].value
    );
    disbursements.at(0).get('amount')?.setValue(disbursementAmountFormat);

    // Only call getDataa() if the loan amount is valid (greater than or equal to 1)
    this.getDataa('load');
  }

  // Interest Rate Slider
  loanInterestRateRangeAction(rangValue: string): void {
    this.loanForm.controls['interestRate'].patchValue(rangValue);
    let interestRates = <FormArray>this.loanForm.controls['interestRates'];
    let interestRateEnter = this.loanForm.controls['interestRate'].value;
    this.inputloanRateRange.nativeElement.value = interestRateEnter;
    //Interest Rate is binding to Advance Calculations interest rate
    interestRates.at(0).get('interestRate')?.setValue(this.loanForm.controls['interestRate'].value);
    // this.onSubmit();
    this.resetForm();
    this.getDataa('load');
  }

  amount: number = 0;
  onSliderChange(event: any) {
    this.amount = event.target.value;
  }

  setMinDateOrigin(): void {
    const today = new Date().toISOString().split('T')[0];
    this.minDateOrigin = today;
  }
  setMinDate(): void {
    const tomorrow = new Date();
    tomorrow.setDate(new Date().getDate() + 1); // Get tomorrow's date
    // Format tomorrow's date in 'YYYY-MM-DD' format
    const formattedTomorrow = tomorrow.toISOString().split('T')[0];
    this.minDate = formattedTomorrow;
  }

  checkCalculateButton(): void {
    this.calculateButtonDisabled = false; // Disable if interestCalcValue is null or undefined
  }

  disableButton(): void {
    this.calculateButtonDisabled = true; // 
  }
  onLoanInterestRateEnter() {
    const interestRateControl = this.loanForm.controls['interestRate'];

    if (!interestRateControl) {
      return;
    }

    const enteredInterestRate = interestRateControl.value;

    // if (enteredInterestRate < 1) {
    //   this.loanEmiService.setMsg({
    //     message: `Interest rate cannot be less than 1.`,
    //     msg_type: 'error',
    //   });
    // } else if (enteredInterestRate > 30) {
    //   this.loanEmiService.setMsg({
    //     message: `Interest rate cannot be more than 30.`,
    //     msg_type: 'error',
    //   });
    // }

    // Set the interest rate in the form and trigger actions related to the form
    let interestRates = <FormArray>this.loanForm.controls['interestRates'];
    this.inputloanRateRange.nativeElement.value = enteredInterestRate;
    interestRates.at(0).get('interestRate')?.setValue(enteredInterestRate);
    this.resetForm()
    this.getDataa('load');
  }

  // Loan Term slider
  loanTermLoanRangeAction(rangValue: string): void {
    this.loanForm.controls['loanTerm'].patchValue(rangValue);
    let tempFinalPaymentDate = moment(this.firstEmiDate)
      .add((this.loanForm.controls['loanTerm'].value - 1), 'M')
      .add(1, 'days').toISOString().substring(0, 10);
    this.finalPaymentDate = tempFinalPaymentDate;
    const periodRange = (start: number, end: number) =>
      Array.from({ length: end - start }, (v, k) => k + start);
    this.periodList = periodRange(1, this.loanForm.controls['loanTerm'].value);
    this.resetForm();
    this.getDataa('load');

  }

  onLoanTermEnter() {
    const loanTermControl = this.loanForm.controls['loanTerm'];
    if (!loanTermControl) {
      return;
    }
    const enteredLoanTerm = loanTermControl.value;
    if (enteredLoanTerm > 360) {
      this.loanEmiService.setMsg({
        message: `Maximum Loan Term is 360`,
        msg_type: 'error',
      });
    }
    // Proceed with API call and related operations only if the loan term is within the valid range
    this.inputloanTermRange.nativeElement.value = enteredLoanTerm;
    const tempFinalPaymentDate = moment(this.firstEmiDate)
      .add(enteredLoanTerm - 1, 'M')
      .add(1, 'days').toISOString().substring(0, 10);

    this.finalPaymentDate = tempFinalPaymentDate;

    const periodRange = (start: number, end: number) =>
      Array.from({ length: end - start }, (v, k) => k + start);

    this.periodList = periodRange(1, enteredLoanTerm);
    this.resetForm();
    this.getDataa('load'); // Call the API function only if the validation check passes
  }

  onSubmit() {
    let interestRates = <FormArray>this.loanForm.controls['interestRates'];
    interestRates.at(0).get('interestRate')?.enable();
    interestRates.at(0).get('effectiveDate')?.enable();
    let disbursements = <FormArray>this.loanForm.controls['disbursements'];
    disbursements.at(0).get('disbursementDate')?.enable();

    this.interestRates = this.loanForm.value.interestRates.map((x: any) => {
      return {
        interestRate: x.interestRate,
        effectiveDate: x.effectiveDate ? new Date(x.effectiveDate).toLocaleDateString('en-GB') : '',
      };
    });
    this.disbursements = this.loanForm.value.disbursements.map((x: any) => {
      return {
        disbursementDate: new Date(x.disbursementDate).toLocaleDateString('en-GB'),
        amount: x.amount,
      };
    });

    this.paymentDues = this.loanForm.value.paymentDues.map((x: any) => {
      return {
        period: Number(x.period),
        amount: Number(x.amount),
      };
    });

    this.getDataa('load');
    this.disableButton();
  }
  resetForm() {

    this.calculateButtonDisabled = true;
    this.showTextBox = false;
    const interestRatesArray = this.loanForm.get('interestRates') as FormArray;
    while (interestRatesArray.length !== 0) {
      interestRatesArray.removeAt(0);
    }
    const disbursementsArray = this.loanForm.get('disbursements') as FormArray;
    while (disbursementsArray.length !== 0) {
      disbursementsArray.removeAt(0);
    }
    const paymentDuesArray = this.loanForm.get('paymentDues') as FormArray;
    while (paymentDuesArray.length !== 0) {
      paymentDuesArray.removeAt(0);
    }

    const loanAmount = this.loanForm.get('loanAmount')?.value;
    const initialInterestRate = interestRatesArray.at(0)?.value;

    // Exclude the first entry from resetting interestRates if it exists
    if (initialInterestRate !== null && initialInterestRate !== undefined) {
      interestRatesArray.clear(); // Remove all entries
      interestRatesArray.push(this.formBuilder.control(initialInterestRate)); // Restore initial value
    }

    this.data = {
      interest: [
        {
          effectiveDate: new Date().toISOString().substring(0, 10),
          interestRate: this.loanForm.get('interestRate')?.value,
        },
      ],
    };
    this.data1 = {
      disbursements: [
        {
          disbursementDate: new Date().toISOString().substring(0, 10),
          amount: this.loanForm.get('loanAmount')?.value.replace(/[^0-9.-]+/g, ''),
        },
      ],
    };
    this.data2 = {
      paymentDues: [
        {
          period: '0',
          amount: 'Full Amount',
        },
      ],
    };
    this.loanForm.patchValue({
      interestCalc: '30/360',
      amortizationMethod: 'normal',
    });
    this.setCompanies();
    this.setCompanies1();
    this.setCompanies2();
    this.getDataa('load');
  }

  getDataa(type = '') {
    this.isLoading = true;
    let interestRatesEnable = <FormArray>(this.loanForm.controls['interestRates']);
    interestRatesEnable.at(0).get('interestRate')?.enable();
    interestRatesEnable.at(0).get('effectiveDate')?.enable();
    let disbursements = <FormArray>this.loanForm.controls['disbursements'];
    disbursements.at(0).get('disbursementDate')?.enable();
    this.interestRates = this.loanForm.value.interestRates.map((x: any) => {
      return {
        interestRate: x.interestRate,
        effectiveDate: x.effectiveDate ? new Date(x.effectiveDate).toLocaleDateString('en-US', {
          month: '2-digit',
          day: '2-digit', year: 'numeric'
        }) : '',
      };
    });

    this.disbursements = this.loanForm.value.disbursements.map((x: any) => {
      return {
        amount: parseFloat(x.amount.replace(/,(?=.*\.)/g, '').split('.')[0]),
        disbursementDate: x.disbursementDate ? new Date(x.disbursementDate).toLocaleDateString('en-US', {
          month: '2-digit',
          day: '2-digit',
          year: 'numeric',
        }) : '',
      };
    });

    this.paymentDues = (this.loanForm.value.paymentDues)
      .map((t: any) => {
        if (t.period == 0) {
          t.period = '';
        }
        if (t.period != 0) {
          t.period = +t.period;
        }
        if (t.amount != 0) {
          if (t.amount == 'Full Amount') {
            t.amount = "-1";
          }
          else {
            t.amount = +t.amount;
          }
        }

        if (t.amount === '') {
          t.amount = -2;
        }
        if (isNaN(t.amount) && t.period == "") {
          t = [];
        }
        return t;
      });
    this.paymentDues = [this.paymentDues[0]];
    let pa = this.loanForm.get('loanAmount')?.value;

    let payload: any = {
      principalAmount: Number(pa.replace(/[^0-9.-]+/g, '')),
      interestRate: +this.loanForm.get('interestRate')?.value,
      terms: +this.loanForm.get('loanTerm')?.value,

      originationDate: this.orinationSelecteDate
        ? new Date(this.orinationSelecteDate)?.toLocaleDateString('en-US', {
          month: '2-digit',
          day: '2-digit',
          year: 'numeric',
        })
        : '',

      initialPaymentDate: this.firstEmiDate
        ? new Date(this.firstEmiDate)?.toLocaleDateString('en-US', {
          month: '2-digit',
          day: '2-digit',
          year: 'numeric',
        })
        : '',

      maturityDate: this.finalPaymentDate
        ? new Date(this.finalPaymentDate)?.toLocaleDateString('en-US', {
          month: '2-digit',
          day: '2-digit',
          year: 'numeric',
        })
        : '',


      advanceEmiCalcParams: {
        fixedInstallment: this.loanForm?.get('textBoxValue')?.value,
        interestRates: this.interestRates,
        disbursements: this.disbursements,
        paymentDues: (type == 'load') ? [] : this.paymentDues,
        amortizationMethod: this.loanForm.get('amortizationMethod')?.value,
        termType: 'months',
      },
    };
    console.log('payload', payload);
    
    const selectedControlValue = this.loanForm.get('amortizationMethod')?.value;
    const textBoxValue = Number(this.loanForm?.get('textBoxValue')?.value.replace(/[^0-9.-]+/g, ''));

    if (selectedControlValue === 'fixedPrincipal') {
      payload.advanceEmiCalcParams.fixedPrincipal = textBoxValue;
      delete payload.advanceEmiCalcParams.fixedInstallment; // Remove fixedInstallment if it exists
    } else if (selectedControlValue === 'fixedInstallment') {
      payload.advanceEmiCalcParams.fixedInstallment = textBoxValue;
      delete payload.advanceEmiCalcParams.fixedPrincipal; // Remove fixedPrincipal if it exists
    }else if (selectedControlValue === 'normal') {
      delete payload.advanceEmiCalcParams.fixedInstallment;
      delete payload.advanceEmiCalcParams.fixedPrincipal;
    }

    const interestCalcValue = this.loanForm.get('interestCalc')?.value;

    if (interestCalcValue === 'Actual/Actual') {
      payload.advanceEmiCalcParams.intCalcDays = 'actuals';
      payload.advanceEmiCalcParams.divisor = 'actuals';
    } else if (interestCalcValue.includes('Actual')) {
      if (interestCalcValue.endsWith('/Actual')) {
        payload.advanceEmiCalcParams.intCalcDays =
          +interestCalcValue.split('/')[0];
        payload.advanceEmiCalcParams.divisor = 'actuals';
      } else if (interestCalcValue.startsWith('Actual/')) {
        payload.advanceEmiCalcParams.intCalcDays = 'actuals';
        payload.advanceEmiCalcParams.divisor = +interestCalcValue.split('/')[1];
      }
    } else if (interestCalcValue.includes('/')) {
      payload.advanceEmiCalcParams.intCalcDays =
        +interestCalcValue.split('/')[0];
      payload.advanceEmiCalcParams.divisor = +interestCalcValue.split('/')[1];
    }

    this.loanEmiService
      .postService(this._apiMapper.endpoints, payload)
      .subscribe({
        next: (data) => {
          if (!data) {
            return;
          }

          this.rowData = data.amortizationSchedules;
          let loanAmountFormat = parseFloat(data.loanAmount).toFixed(2);
          this.loanAmount = loanAmountFormat.replace(
            /\B(?=(\d{3})+(?!\d))/g,
            ','
          );

          let monthlyEmiFormat = parseFloat(data.monthlyEmi).toFixed(2);
          this.monthlyEmi = monthlyEmiFormat.replace(
            /\B(?=(\d{3})+(?!\d))/g,
            ','
          );

          let totalInterestFormat = parseFloat(
            data.totalInterestAmount
          ).toFixed(2);
          this.totalInterestAmount = totalInterestFormat.replace(
            /\B(?=(\d{3})+(?!\d))/g,
            ','
          );

          let totalOutStandingFormat = parseFloat(
            data.totalOutStandingBalance
          ).toFixed(2);
          this.totalOutStandingBalance = totalOutStandingFormat.replace(
            /\B(?=(\d{3})+(?!\d))/g,
            ','
          );

          let totalInterest = +(
            (+totalInterestFormat * 100) /
            +totalOutStandingFormat
          ).toFixed(2);
          let principalPer = 100 - totalInterest;
          principalPer = parseFloat(principalPer.toFixed(2));
          let formatDate = [
            {
              asset: 'Principal',
              amount: principalPer,
            },
            {
              asset: 'Interest',
              amount: totalInterest,
            },
          ];
          this.manulpulatePiCart(formatDate);
          this.lineChart(this.rowData);
          this.addingFooter();
          this.isLoading = false;
        },
        error: (err) => {
          this.isLoading = false;
          this.loanEmiService.setMsg({
            message: `${err.error.message}`,
            msg_type: 'error',
          });
        },
      });
    let interestRates = <FormArray>this.loanForm.controls['interestRates'];
    interestRates.at(0).get('interestRate')?.disable();
    interestRates.at(0).get('effectiveDate')?.disable();
    let disbursementsDisable = <FormArray>(
      this.loanForm.controls['disbursements']
    );
    disbursementsDisable.at(0).get('disbursementDate')?.disable();
  }

  lineChart(rowData: any[]) {
    let obj: any = {};
    let lastEndingBalances: { [key: string]: number } = {};

    rowData.forEach((item, index) => {
      if (obj[item.year]) {
        obj[item.year]['regularPrincipal'] += item.regularPrincipal;
        obj[item.year]['regularInterest'] += item.regularInterest;
      } else {
        obj[item.year] = {
          regularPrincipal: item.regularPrincipal || 0,
          regularInterest: item.regularInterest || 0,
        };
      }
      // Store the endingBalance for each year
      lastEndingBalances[item.year] = item.endingBalance || 0;
    });

    let tempRow = Object.entries(obj).map((item: any) => {
      return {
        year: item[0],
        regularPrincipal: item[1].regularPrincipal || 0,
        endingBalance: lastEndingBalances[item[0]] || 0,
        regularInterest: item[1].regularInterest || 0,
      };
    });

    this.options1 = {
      ...this.options1,
      data: tempRow,
      endingBalanceData: lastEndingBalances,
    };
    //option 2 , normal data
    let lineChartWithPeriod = this.rowData.map((item: any) => {
      return {
        period: item['period'],
        regularPrincipal: item['regularPrincipal'] || 0,
        endingBalance: item['endingBalance'] || 0,
        regularInterest: item['regularInterest'] || 0,
      };
    });

    this.options2 = {
      ...this.options2,
      data: lineChartWithPeriod,
    };
  }
  onChangeOriginationDate(event: any): void {
    this.orinationSelecteDate = event;
    this.firstEmiDate = moment(event)
      .add(1, 'M')
      .add(1, 'days')
      .toISOString()
      .substring(0, 10);

    let tempFinalPaymentDate = moment(this.firstEmiDate)
      .add((this.loanForm.controls['loanTerm'].value - 1), 'M')
      .add(1, 'days')
      .toISOString()
      .substring(0, 10);

    this.finalPaymentDate = tempFinalPaymentDate;
debugger
    // Update the effective date in interest rates FormArray
    const interestRatesFormArray = this.loanForm.get(
      'interestRates'
    ) as FormArray;
    // Update only the first row in the interestRates FormArray
    if (interestRatesFormArray.controls.length > 0) {
      const firstRowFormGroup = interestRatesFormArray.at(0) as FormGroup;
      firstRowFormGroup.patchValue({ effectiveDate: event });
    }
    interestRatesFormArray.controls.forEach((control) => {
      if (control instanceof FormGroup) {
        control.patchValue({ effectiveDate: event });
      }
    });

    // Update the disbursement date in disbursements FormArray
    const disbursementsFormArray = this.loanForm.get(
      'disbursements'
    ) as FormArray;

    disbursementsFormArray.controls.forEach((control) => {
      if (control instanceof FormGroup) {
        control.patchValue({ disbursementDate: event });
      }
    });

    // Call getDataa() after updating both interestRates and disbursements FormArrays
    this.getDataa('load');
  }

  onChangeFirstEmi(event: any): void {
    this.firstEmiDate = event
    let tempFinalPaymentDate = moment(this.firstEmiDate)
      .add((this.loanForm.controls['loanTerm'].value - 1), 'M')
      .add(1, 'days')
      .toISOString()
      .substring(0, 10);
    this.finalPaymentDate = tempFinalPaymentDate;
    this.getDataa('load');
  }



  getOriginationDate() {
    this.firstEmiDate = moment(this.orinationSelecteDate)
      .add(1, 'M')
      .add(1, 'days')
      .toISOString()
      .substring(0, 10);

    let tempFinalPaymentDate = moment(this.firstEmiDate)
      .add((this.loanForm.controls['loanTerm'].value - 1), 'M')
      .add(1, 'days')
      .toISOString()
      .substring(0, 10);
    this.finalPaymentDate = tempFinalPaymentDate;
    this.getDataa('load');
  }

  onGridReady(params: any) {
    params.api.sizeColumnsToFit();
    this.params = params;
  }

  addingFooter() {
    let regularInterest = 0;
    let regularPaymentDue = 0;
    let regularPrincipal = 0;
    this.rowData.map((data: any) => {
      regularInterest += +data.regularInterest;
      regularPaymentDue += +data.regularPaymentDue;
      regularPrincipal += +data.regularPrincipal;
    });

    this.params.api.setPinnedBottomRowData([
      {
        data: 'Total ',
        regularPrincipal: regularPrincipal,
        regularInterest: regularInterest,
        regularPaymentDue: regularPaymentDue,
      },
    ]);
  }

  //ag grid column initialization
  public columnDefs: ColDef[] = [
    {
      field: 'year',
      chartDataType: 'category',
      rowGroup: true,
      filter: false,
      editable: false
    },
    {
      field: 'period',
      chartDataType: 'category',
      filter: false,
      editable: false
    },
    {
      headerName: 'Date',
      field: 'paymentDate',
      maxWidth: 160,
      filter: false,
      editable: false
    },
    {
      headerName: 'Principal (A)',
      field: 'regularPrincipal',
      maxWidth: 160,
      // aggFunc: 'sum',
      cellStyle: {
        'text-align': 'right',
      },
      valueFormatter: this.helper.CurrencyCellRendererRoundOff,
      filter: false,
      chartDataType: 'series',
      aggFunc: 'mySum',
      editable: false
    },
    {
      headerName: 'Interest (B)',
      field: 'regularInterest',
      maxWidth: 160,
      aggFunc: 'mySum',
      cellStyle: {
        'text-align': 'right',
      },
      valueFormatter: this.helper.CurrencyCellRendererRoundOff,
      filter: false,
      editable: false
    },
    {
      headerName: 'Payment (A+B)',
      field: 'regularPaymentDue',
      maxWidth: 180,
      aggFunc: 'sum',
      cellStyle: {
        'text-align': 'right',
      },
      valueFormatter: this.helper.CurrencyCellRendererRoundOff,
      filter: false,
      editable: false
    },
    {
      headerName: 'Cumulative Interest',
      field: 'totalInterest',
      maxWidth: 180,
      filter: false,
      editable: false,
      chartDataType: 'category',
      aggFunc: 'totalInterest',
      cellStyle: {
        'text-align': 'right',
      },
      valueFormatter: (params: any) => {
        if (params.value || params.value === 0) {
          return parseFloat(params.value)
            .toFixed(2)
            .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        }
        return '';
      },
    },
    {
      headerName: 'Remaining Balance',
      field: 'endingBalance',
      maxWidth: 190,
      filter: false,
      editable: false,
      sortable: true,
      cellStyle: {
        'text-align': 'right',
      },
      cellClass: 'exportValueTwoDecimalPlaces',
      valueFormatter: (params: any) => {
        if (params.value || params.value === 0) {
          return parseFloat(params.value)
            .toFixed(2)
            .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        }
        return '';
      },
      aggFunc: 'lastEndingBalanceGrid', // Associate the custom aggregation function
    },
    {
      headerName: 'Loan Paid %',
      field: 'loanPaid',
      maxWidth: 160,
      filter: false,
      sortable: true,
      editable: false,
      cellStyle: {
        'text-align': 'right',
      },
      cellClass: 'exportValueTwoDecimalPlaces',
      valueFormatter: (params: any) => {
        if (params.value || params.value === 0) {
          return parseFloat(params.value)
            .toFixed(2)
            .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        }
        return '';
      },
    },
  ];

  public gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
  };

  public aggFuncs: {
    [key: string]: IAggFunc;
  } = {
      mySum: (params: IAggFuncParams) => {
        let sum = 0;
        params.values.forEach((value: number) => {
          sum += value;
        });
        return sum;
      },

      lastEndingBalanceGrid: (params: IAggFuncParams) => {
        const data = params.rowNode.allLeafChildren;
        const lastEndingBalances: number[] = [];

        const lastEndingBalanceByYear: Record<string, number> = {};

        data.forEach((row: any) => {
          const year = row.data.year;
          const endingBalance = parseFloat(row.data.endingBalance);
          if (!isNaN(endingBalance) && year) {
            lastEndingBalanceByYear[year] = endingBalance;
          }
        });

        // Iterate over unique years and push their respective ending balance to the array
        const uniqueYears = [...new Set(Object.keys(lastEndingBalanceByYear))];
        uniqueYears.forEach((year) => {
          lastEndingBalances.push(lastEndingBalanceByYear[year]);
        });

        return lastEndingBalances;
      },
      totalInterest: (params: IAggFuncParams) => {
        const data = params.rowNode.allLeafChildren;
        const totalInterests: number[] = [];

        const totalInterestByYear: Record<string, number> = {};

        data.forEach((row: any) => {
          const year = row.data.year;
          const totalInterest = parseFloat(row.data.totalInterest);

          if (!isNaN(totalInterest) && year) {
            totalInterestByYear[year] = totalInterest;
          }
        });

        // Iterate over unique years and push their respective total interest to the array
        const uniqueYears = [...new Set(Object.keys(totalInterestByYear))];
        uniqueYears.forEach((year) => {
          totalInterests.push(totalInterestByYear[year]);
        });

        return totalInterests;
      },
    };

  //defaultColDef definitions
  public defaultColDef: ColDef = {
    flex: 1,

    editable: true,
    sortable: true,
    filter: false,
    floatingFilter: false,
    resizable: true,
    suppressSizeToFit: true,
  };

  public chartThemes: string[] = ['ag-default'];
  public chartThemeOverrides: AgChartThemeOverrides = {
    cartesian: {
      axes: {
        category: {
          label: {
            rotation: 0,
          },
        },
      },
    },
  };
}

function tooltipRenderer({
  datum,
  xKey,
  yKey,
}: AgCartesianSeriesTooltipRendererParams) {
  // Format the yKey value with commas for thousands separators and two decimal places
  const formattedYValue = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(datum[yKey]);

  return {
    content: `${datum[xKey]}: ${formattedYValue}`,
  };
}
const PRINCIPAL: AgBarSeriesOptions = {
  type: 'bar',
  xKey: 'year',
  yKey: 'regularPrincipal',
  yName: 'Principal',
  grouped: true,
  tooltip: {
    renderer: tooltipRenderer,
  },
};

const TOTAL_INTEREST: AgBarSeriesOptions = {
  type: 'bar',
  xKey: 'year',
  yKey: 'regularInterest',
  yName: 'Interest',
  grouped: true,
  tooltip: {
    renderer: tooltipRenderer,
  },
};

const BALANCE: AgLineSeriesOptions = {
  type: 'line',
  xKey: 'year',
  yKey: 'endingBalance',
  yName: 'Balance',
  tooltip: {
    renderer: tooltipRenderer,
  },
};
const BAR_AND_LINE: AgCartesianSeriesOptions[] = [
  {
    ...PRINCIPAL,
    type: 'bar',
  },
  {
    ...TOTAL_INTEREST,
    type: 'bar',
  },
  {
    ...BALANCE,
    type: 'line',
  },
];

// chart 2 line chart
const PRINCIPAL1: AgBarSeriesOptions = {
  type: 'bar',
  xKey: 'period',
  yKey: 'regularPrincipal',
  yName: 'Principal',
  grouped: true,
  tooltip: {
    renderer: tooltipRenderer,
  },
};

const TOTAL_INTEREST1: AgBarSeriesOptions = {
  type: 'bar',
  xKey: 'period',
  yKey: 'regularInterest',
  yName: 'Interest',
  grouped: true,
  tooltip: {
    renderer: tooltipRenderer,
  },
};

const BALANCE1: AgLineSeriesOptions = {
  type: 'line',
  xKey: 'period',
  yKey: 'endingBalance',
  yName: 'Balance',
  tooltip: {
    renderer: tooltipRenderer,
  },
};
const BAR_AND_LINE1: AgCartesianSeriesOptions[] = [
  {
    ...PRINCIPAL1,
    xKey: 'period',
    yKey: 'regularPrincipal',
    type: 'bar',
  },
  {
    ...TOTAL_INTEREST1,
    xKey: 'period',
    yKey: 'regularInterest',
    type: 'bar',
  },
  {
    ...BALANCE1,
    type: 'line',
  },
];
