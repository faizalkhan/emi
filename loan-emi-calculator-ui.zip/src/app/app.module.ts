import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoanEmiCalculatorComponent } from './loan-emi-calculator/loan-emi-calculator.component';
import { HttpClientModule } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from 'ag-grid-enterprise';
import { LoanEmiServiceService } from './loan-emi-calculator/services/loan-emi-service.service';
import { CommonModule, formatDate } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
const lk = "CompanyName=Idexcel, Inc.,LicensedApplication=cyncsoftware.com,LicenseType=SingleApplication,LicensedConcurrentDeveloperCount=1,LicensedProductionInstancesCount=1,AssetReference=AG-039231,SupportServicesEnd=8_May_2024_[v2]_MTcxNTEyMjgwMDAwMA==d9f379bc9dd80c4ac119c45aca833998";
LicenseManager.setLicenseKey(lk);
import { CalendarModule } from 'primeng/calendar';
import { SelectButtonModule } from 'primeng/selectbutton';
import { AgChartsAngularModule } from 'ag-charts-angular';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatNativeDateModule, NativeDateAdapter} from '@angular/material/core';
// import { MomentDateAdapter } from '@angular/material-moment-adapter';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSliderModule } from '@angular/material/slider';

class PickDateAdapter extends NativeDateAdapter {
  override format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      return formatDate(date, 'dd MMM yyyy', this.locale);
    } else {
      return date.toDateString();
    }
  }
 }

@NgModule({
  declarations: [
    AppComponent,
    LoanEmiCalculatorComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    CommonModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    AgGridModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    CalendarModule,
    AgChartsAngularModule,
    MatSliderModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    SelectButtonModule,
    MessagesModule,
    MessageModule,
    MatProgressSpinnerModule
  ],
  providers: [LoanEmiServiceService,
    { provide: DateAdapter, useClass: PickDateAdapter },
    // { provide: MAT_DATE_FORMATS, useValue: dateFormatWithMonthName }
  
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
