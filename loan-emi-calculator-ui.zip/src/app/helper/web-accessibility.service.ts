import { Injectable } from "@angular/core";
import * as _ from "lodash";
@Injectable({
    providedIn: "any",
})
export class WebAccessibilityService {
    // variable declaration section
    isScreenName = ['loan-enquiry', 'loan-summary']
    constructor() { }
    /**
     *
     * @param arrElm  selected Elements
     * @param titleVal  selected titles
     * @param role selected roles
     * @param arialabel selected label
     * @param placeholder selected label
     */
    listArrayWebAccess(arrElm: HTMLElement[],titleVal: string,arialabel: string,role: string = "default",placeholder: string = "default") {
      arrElm.forEach((elm) => {
           elm.setAttribute("title", titleVal);
           elm.setAttribute("aria-hidden", "true");
           elm.setAttribute("tabindex", "-1");
           elm.setAttribute("aria-label", arialabel);
            if (placeholder != "default") 
                elm.setAttribute("placeholder", placeholder);
            if (role !== "default") 
                elm.setAttribute("role", role);
       });
    }
    normalWebAccess(arrElm: HTMLElement,titleVal: string,role: string,arialabel: string,placeholder: string = "default") {
        arrElm.setAttribute("title", titleVal);
        arrElm.setAttribute("aria-hidden", "true");
        arrElm.setAttribute("tabindex", "-1");
        arrElm.setAttribute("role", role);
        arrElm.setAttribute("aria-label", arialabel);
        if (placeholder != "default") 
            arrElm.setAttribute("placeholder", placeholder);
    }

    /**
     * This method to call Every where component lable
     * @param view   particular Selected complete element which is come from component viewref
     * @param elmentSelect   apply that applied  component
     * @param screenName  specify screen name
     * @param grid  specify grid name
     */
    accesibiltyValidation(view: any,elmentSelect: string = "default",screenName: string = "default",grid: string = "default") {
        const header_doc = view;

        // ag grid Section 
        if(elmentSelect =="ag-grid"){
        setTimeout(() => {
            
            let ag_grid_div = header_doc.querySelector("ag-grid-angular");
            let ag_grid_arr = ag_grid_div.querySelectorAll(".ag-tab-guard");
            this.listArrayWebAccess(ag_grid_arr, "ag-tab-guard title","ag-tab-guard role","ag-tab-guard arialabel" );
            let ag_grid_disabled = ag_grid_div.querySelectorAll(".ag-header-cell");
            
            ag_grid_disabled.forEach((elm:any) => {
                elm.setAttribute("title", "titleVal");
                elm.setAttribute("aria-hidden", "true");
                elm.setAttribute("tabindex", "-1");
                elm.setAttribute("aria-label", "arialabel");
               
                     elm.setAttribute("role", "role");
            });


        }, 2000);
    }
  // ag grid Section 
        if(elmentSelect =="ag-grid payment"){
            setTimeout(() => {
            let ag_img= header_doc.querySelectorAll("app-imge-link img");
            ag_img.forEach((elm: { setAttribute: (arg0: string, arg1: string) => void; })=> {
                elm.setAttribute("alt", "app-imge-link");
            })
            }, 1500);
        }

        // ag grid Section end

        //upload file
        if(elmentSelect == "table" && screenName == "upload-pending-file" ){
        setTimeout(() => {
            let upload_req_arr = header_doc.querySelectorAll("table input");
            this.listArrayWebAccess(upload_req_arr,"table input placeholder","table input title", "table input aria label");
            let upload_req_text_arr = header_doc.querySelector("textarea");
            this.normalWebAccess(upload_req_text_arr,"textarea title","textarea place holder","textarea aria-label");
        }, 1200);
    }
        if(elmentSelect == "table" && screenName == "upload-file" ){
        setTimeout(() => {
            let upload_req_arr = header_doc.querySelectorAll("ul li");
            this.listArrayWebAccess(upload_req_arr,"table input placeholder","table input title", "table input aria label");
            let upload_req_tbody = header_doc.querySelectorAll("table tbody");
            this.listArrayWebAccess(upload_req_tbody,"table body title","table body place holder","table body aria-label","table body aria-label");
        }, 1200);
    }
        // end upload file

        //p-dropdown only
        if (elmentSelect == "p-selectbutton") {
            setTimeout(() => {
                let seach_elment = header_doc;                                
                let buttonAr = seach_elment.querySelectorAll("p-selectbutton div div[role='button'],p-dropdown div input[type='button'], p-dropdown div input[type='text']");                
                this.listArrayWebAccess(buttonAr,"p-dropdown title","p-dropdown aria-label");
            }, 1000);
        }
        //p-dropdown only ends

        // loan-enquiry screen starts
        else if (elmentSelect == "p-calender" && screenName == "loan-enquiry" && grid == "ag-grid") {
            let seach_elment = header_doc.querySelector("app-from-to-date-search");
            let buttonAr = seach_elment.querySelectorAll("p-calendar span button[type='button'],  p-calendar span input");
            this.listArrayWebAccess(buttonAr,"p-calendar in loan enquiry title", "p-calendar in loan enquiry aria-label");
            let ag_grid_select = header_doc.querySelector("ag-grid-angular");
            setTimeout(() => {
                let checkAgGridAr = ag_grid_select.querySelectorAll(" div input[type='checkbox']");
                this.listArrayWebAccess(checkAgGridAr,"ag-grid-angular checkbox title "," ag-grid-angular checkbox aria-label ");
                let filter_elment_arr = ag_grid_select.querySelectorAll("app-loading-overlay");
                    filter_elment_arr.forEach((inputField: { querySelectorAll: (arg0: string) => any; }) => {
                    let inputFieldArr = inputField.querySelectorAll("input[type='text']");
                    this.listArrayWebAccess(inputFieldArr, "app-loading-overlay title", "app-loading-overlay role","app-loading-overlay aria-label");
                });
                let ag_grid_arr = ag_grid_select.querySelectorAll(".ag-tab-guard");
                this.listArrayWebAccess(ag_grid_arr, "ag-tab-guard title","ag-tab-guard role","ag-tab-guard arialabel" );
                let ag_grid_viewport = ag_grid_select.querySelector(".ag-body-viewport");
                this.normalWebAccess(ag_grid_viewport,"viewport title","viewport place holder","viewport aria-label");
            }, 1000);
        }
        // loan-enquiry screen end

        //import-invoice screen 
        else if (elmentSelect == "p-calender" && screenName == "import-invoice" && grid == "mat-grid") {
            setTimeout(() => {
                let import_elm = header_doc.querySelectorAll("mat-accordion mat-panel-description form p-calendar, mat-accordion mat-panel-description form input");
                this.listArrayWebAccess(import_elm,"mat-grid p-calendar title in import invoice", "mat-grid p-calendar in loan enquiry aria-label");
            }, 600);

        }
        //import-invoice screen ends

        // p-calender starts
        else if (elmentSelect == "p-calender") {
            let seach_elment = header_doc;
            let buttonAr = seach_elment.querySelectorAll("p-calendar span button[type='button'],  p-calendar span input");
            this.listArrayWebAccess(buttonAr,"p-calendar  title","p-calendar aria-label");
            let ag_grid_div = header_doc.querySelector("ag-grid-angular");
            let ag_grid_arr = ag_grid_div.querySelectorAll(".ag-tab-guard");
            this.listArrayWebAccess(ag_grid_arr,"ag-grid-angular ag-tab-guard title","ag-grid-angular ag-tab-guard role");
        }
        // p-calender end

        // loan-summary screen starts
        else if (elmentSelect == "p-cal" && screenName == "loan-summary" && grid == "ag-grid") {
            let ag_grid_select = header_doc.querySelector("ag-grid-angular");
            setTimeout(() => {
                let checkAgGridAr = ag_grid_select.querySelectorAll(" div input[type='checkbox']" );
                this.listArrayWebAccess( checkAgGridAr, "ag-grid-angular checkbox title", "ag-tab-guard checkbox aria-label");
                let filter_elment_arr = ag_grid_select.querySelectorAll("app-loading-overlay");
                filter_elment_arr.forEach((inputField: { querySelectorAll: (arg0: string) => any; }, index: any) => {
                    let inputFieldArr = inputField.querySelectorAll("input[type='text']");
                    this.listArrayWebAccess(inputFieldArr,"app-loading-overlay inputField", "app-loading-overlay inputField","app-loading-overlay inputField" );

                });
                let ag_grid_arr = ag_grid_select.querySelectorAll(".ag-tab-guard");
                this.listArrayWebAccess(ag_grid_arr, "ag-tab-guard title","ag-tab-guard role","ag-tab-guard arialabel" );              
                let ag_grid_viewport = ag_grid_select.querySelector(".ag-body-viewport");
                this.normalWebAccess(ag_grid_viewport,"viewport title","viewport place holder","viewport aria-label");
            }, 1000);

        }
        // loan-summary screen starts ends

        // fund-request screen starts

         else if (elmentSelect == "p-cal" && screenName == "fund-request" && grid == "ag-grid" ) {
            let seach_elment = header_doc.querySelector("app-fund-request-activity");     
            let fund_req = header_doc;     
            let fund_control = fund_req.querySelectorAll("p-calendar span button[type='button'],  p-calendar span input[text='text'], form textarea ,form input" );
            let fund_p_dropdown = fund_req.querySelectorAll("p-dropdown");
            this.listArrayWebAccess(fund_p_dropdown,"p-dropdown title","p-dropdown aria-label");
            this.listArrayWebAccess(fund_control,"fund-request screen p-calendar title","fund-request screen p-calendar placeholder","fund-request screen p-calendar aria-label");
            let ag_grid_fund = seach_elment.querySelector("ag-grid-angular");
            setTimeout(() => {
                let checkAgGridAr = ag_grid_fund.querySelectorAll(" div input[type='checkbox']");
                this.listArrayWebAccess(checkAgGridAr,"fund-request screen ag-grid-angular title ","fund-request screen ag-grid-angular aria-label ","fund-request screen ag-grid-angular title " );
                let filter_elment_arr = ag_grid_fund.querySelector("app-loading-overlay input");
                this.normalWebAccess( filter_elment_arr,"fund-request screen ag-grid-angular title","fund-request screen ag-grid-angular role","fund-request screen ag-grid-angular aria-label" );
                let ag_grid_arr = ag_grid_fund.querySelectorAll(".ag-tab-guard");
                this.listArrayWebAccess(ag_grid_arr, "ag-tab-guard title","ag-tab-guard role","ag-tab-guard arialabel" );
                let buttonAr = seach_elment.querySelectorAll("p-dropdown div div[role='button'],p-dropdown div input[type='button'], p-dropdown div input[type='text']");
                this.listArrayWebAccess(buttonAr,"p-dropdown title","p-dropdown aria-label");
                let ag_grid_viewport = ag_grid_fund.querySelector(".ag-body-viewport");
                this.normalWebAccess(ag_grid_viewport,"viewport title","viewport place holder","viewport aria-label");
            }, 1000);
        }
         // fund-request screen ends
    }
}