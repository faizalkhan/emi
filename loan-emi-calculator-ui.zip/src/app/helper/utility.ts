import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'any'
})
export class APIMapper {

    endpoints: any;

    constructor() {
       this.endpoints = this.endPointConfiguration();
    
    }
    endPointConfiguration(): any{
        let lender = window.location.hostname.split('.')[0];
        let apiConfig:any = {
            "dev2":"https://apidevbase.cyncsoftware.com/api/loan-emi/calculator",
            "staging":"https://apistagingbase.cyncsoftware.com/api/loan-emi/calculator",
            "uattest":"https://apiuatbase.cyncsoftware.com/api/loan-emi/calculator"
        }
        lender = (lender == 'localhost') ? 'staging' : lender
        return apiConfig[lender];
    }


}