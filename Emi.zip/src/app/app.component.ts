import { Component } from '@angular/core';
import { Message, MessageService } from 'primeng/api';
import { LoanEmiServiceService } from './loan-emi-calculator/services/loan-emi-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [MessageService],
})
export class AppComponent {
  title = 'cync-loan-emi-calculator';
  public msgs: Message[] | any;

  constructor(
    private messageService: MessageService,
    private loanEmiService: LoanEmiServiceService
  ) {}
  ngOnInit() {
    this.loanEmiService.getMsg().subscribe((data) => {    
     
      if (data.msg_type === 'error' && parseInt(data.message) < 30) {
        this.msgs = [];
      } else {
        this.msgs = [
          {
            severity: `${data.msg_type}`,
            summary: 'Error',
            detail: `${data.message}`,
          },
        ]; 
        this.messageClear();
      }
    });
  
  }

  messageClear() {
    setTimeout(() => {
      this.msgs = [];
    }, 5000);
  }
}
