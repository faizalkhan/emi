import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Helper {
  constructor() {}
  /**
   * my local token to run angular application
   */
  getMyLocalToken(): string {
    return 'eyJhbGciOiJIUzI1NiJ9.eyJkYXRhIjp7ImF1dGhlbnRpY2F0aW9uX3Rva2VuIjoidC1Sc1l0RTZNOFNBeDd4VVV6NGIiLCJ1c2VyX2lkIjozMDMsInJvbGUiOiJBIiwidXNlcl9uYW1lIjoiQWlzaHdhcnlhX2RldjIiLCJyb2xlX2lkIjozfSwiZXhwIjoxNzAyOTI5MTM4fQ.NB3jf9dwRUsYwa4HVl_JA28CyZ9wx1aDeW2dXIzgi-s';
  }

  /**
   * formating number value with 2 decimal point
   * @param params
   *
   */
  CurrencyCellRendererRoundOff(params: any) {
    var usdFormate = new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
    });
    let usdFormatedValue = '';
    if (params.value === undefined) {
      let v = parseFloat(params).toFixed(2);
      usdFormatedValue = usdFormate.format(Number(v));
    } else if (
      (params.value === '' || params.value === null) &&
      typeof params != 'string'
    ) {
      let v = parseFloat('0').toFixed(2);
      usdFormatedValue = usdFormate.format(Number(v));
    } else if (typeof params == 'string') {
      let v = parseFloat(params).toFixed(2);
      usdFormatedValue = usdFormate.format(Number(v));
    } else {
      let v = parseFloat(params.value).toFixed(2);
      usdFormatedValue = usdFormate.format(Number(v));
    }

    if (usdFormatedValue.indexOf('-') !== -1) {
      return '(' + usdFormatedValue.replace('-', '') + ')';
    } else {
      return usdFormatedValue;
    }
  }

    /**
      * formating number value with 2 decimal point
      * @param params 
      *
      */
    emiCurrencyFormat(params: any) {
  
      var usdFormate = new Intl.NumberFormat('en-US', {
          // minimumFractionDigits: 2
      });
      let usdFormatedValue = '';
      if (params === undefined) {
          let v = parseFloat(params);
          usdFormatedValue = usdFormate.format(Number(v));
      }
      else {
          let v = parseFloat(params);
          usdFormatedValue = usdFormate.format(Number(v));
      }

      if (usdFormatedValue.indexOf('-') !== -1) {
          return "(" + usdFormatedValue.replace('-', '') + ")";
      } else {
          return usdFormatedValue;
      }

  }
  emiCurrencyFormat2(params: any) {
    let param2 = (params).toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
    })
    return param2;
  }
}
