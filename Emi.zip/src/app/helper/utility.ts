import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'any'
})
export class APIMapper {

    endpoints: any;

    constructor() {
       this.endpoints = this.endPointConfiguration();
    
    }
    endPointConfiguration(): any{
        let apiConfig = {
            // https://apidevbase.cyncsoftware.com/api/loan-emi/calculator
            "emiCalculator":"https://apidevbase.cyncsoftware.com/api/loan-emi/calculator",
        }
        return apiConfig;
    }


}