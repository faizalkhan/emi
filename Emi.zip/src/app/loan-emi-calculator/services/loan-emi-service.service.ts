import { Injectable } from '@angular/core';

import { HttpClient, HttpEvent, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { Helper } from 'src/app/helper/helper';
declare var window: any;

@Injectable({
  providedIn: 'root',
})
export class LoanEmiServiceService {
  public lenderId: string;
  // private msgText: Subject<any> = new Subject<any>();
  private msgText: BehaviorSubject<any> = new BehaviorSubject<any>(null);
 
  constructor(private httpclient: HttpClient,
    private _helper: Helper) {
    let fd = window.origin;
    let dn = fd.split("//")[1].split(":")[0];
    this.lenderId = dn.split(".")[0];
  }

  getService(url: string): Observable<any> {
    return this.httpclient.get(url, {
      headers: this.requestHeadersWithAuth()
    });
  }

  getServiceAmoz(url: string, obj:any): Observable<any> {

    let params = new HttpParams()

      .set('principalAmount', obj.principalAmount)
      .set('terms', obj.terms)
      .set('termType', obj.termType)
      .set('originationDate', obj.originationDate)
      .set('initialPaymentDate', obj.initialPaymentDate)
      .set('intCalcDay', obj.intCalcDay)
      .set('yearDivisor', obj.yearDivisor)
      .set('interestRate', obj.interestRate)
      .set('fixedInstallment', obj.fixedInstallment)
      .set('isEditedFixedInstallment', obj.isEditedFixedInstallment.toString());

    return this.httpclient.get(url, {params});
  }

  getServiceAmoz1(url: string, obj:any): Observable<any> {
    
    let params = new HttpParams()

      .set('principal', obj.principalAmount)
      .set('terms', obj.terms)
      .set('isEditedFixedPrincipal', obj.isEditedFixedPrincipal)
      .set('fixedPrincipal', obj.fixedPrincipal)


    return this.httpclient.get(url, {params});
  }




  getServiceText(url: string): Observable<any> {

    return this.httpclient.get(url, {
      headers: this.requestHeadersWithAuth(),
      responseType: 'text'
    });
  }

  delService(url: string): Observable<any> {
    const httpOptions = {
      headers: this.requestHeadersWithAuth(),
    };
    return this.httpclient.delete(url, httpOptions);
  }

  putService(url: string, payload_body: any): Observable<any> {
    const httpOptions = {
      headers: this.requestHeadersWithAuth(),
    };
    return this.httpclient.put(url, payload_body, httpOptions);
  }

  patchService(url: string, payload_body: any): Observable<any> {
    const httpOptions = {
      headers: this.requestHeadersWithAuth(),
    };

    return this.httpclient.patch(url, payload_body, httpOptions);
  }

  postService(url: string, payload_body: any): Observable<any> {
    return this.httpclient.post(url, payload_body);
  }



  requestHeadersWithAuth(): HttpHeaders {
    const httpHeader: HttpHeaders = new HttpHeaders({
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': this.getBearerToken(),
      'Access-Control-Allow-Origin':'*',
      'lenderId':'dev2' //this.lenderId
    });
    return httpHeader;
  }

  getBearerToken(): string {
    return 'Bearer '
  }

  getMsg(): Observable<any> {
    return this.msgText.asObservable();
  }
  // Method to set the error message
  setMsg(value: any): void {
    this.msgText.next(value);
  }

  // Method to clear the error message
  clearMsg(): void {
    console.log('clearMsg',this.msgText)
    if(this.msgText) this.msgText.next(null); // Clear the error message by emitting null
  }
}
