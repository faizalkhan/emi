var numRows = 500;

var names = [
  'Principal Amount',
  'Total Interest Amount',
];

var phones = [
  { handset: 'Huawei P40', price: 599 },
  { handset: 'Google Pixel 5', price: 589 },
  { handset: 'Apple iPhone 12', price: 849 },
  { handset: 'Samsung Galaxy S10', price: 499 },
  { handset: 'Motorola Edge', price: 549 },
  { handset: 'Sony Xperia', price: 279 },
];

export function getData11(): any[] {
  var data: any[] = [];
  for (var i = 0; i < numRows; i++) {
    var phone = phones[getRandomNumber(0, phones.length)];
    var saleDate = randomDate(new Date(2020, 0, 1), new Date(2020, 11, 31));
    var quarter = 'Q' + Math.floor((saleDate.getMonth() + 3) / 3);

    data.push({
      salesRep: names[getRandomNumber(0, names.length)],
      handset: phone.handset,
      sale: phone.price,
      saleDate: saleDate,
      quarter: quarter,
    });
  }

  data.sort(function (a, b) {
    return a.saleDate.getTime() - b.saleDate.getTime();
  });

  data.forEach(function (d) {
    d.saleDate = d.saleDate.toISOString().substring(0, 10);
  });

  return data;
}

function getRandomNumber(min: number, max: number) {
  return Math.floor(Math.random() * (max - min) + min);
}

function randomDate(start: Date, end: Date) {
  return new Date(
    start.getTime() + Math.random() * (end.getTime() - start.getTime())
  );
}

export function getData() {
  return [
      { asset: 'Stocks', amount: 60000 },
      { asset: 'Bonds', amount: 40000 },
      { asset: 'Cash', amount: 7000 },
      { asset: 'Real Estate', amount: 5000 },
      { asset: 'Commodities', amount: 3000 },
  ];
}
