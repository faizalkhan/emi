import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { DOCUMENT } from '@angular/common';

export interface EnvConfig {
  env: string;
}
export interface APIHostConfig {}
@Injectable({ providedIn: 'any' })
export class AppConfig {
  public config: any;
  public env: any;
  private lender: string[] | undefined;
  private envName: any;
    cyncCookie: string | undefined;

  
    /**
     * 
     * @param document 
     * @param httpClient 
     * @param cookieService 
     */
    constructor(
        @Inject(DOCUMENT) private document: any,
        private httpClient: HttpClient,
        private cookieService: CookieService) {

    }
  /**
     * This method:
     *   a) Loads "env.json" to get the current working environment (e.g.: 'production', 'development')
     *   b) Loads "config.[env].json" to get all env's variables (e.g.: 'config.development.json')
     */
  public load() {
    return new Promise((resolve, reject) => {
        debugger
        this.httpClient.get<EnvConfig>('./assets/environment/env.json?v=1001').subscribe(envResponse => {
            let tempEnvResponse = envResponse;
            this.env = tempEnvResponse.env;
            this.envName = tempEnvResponse.env;
            this.httpClient.get<APIHostConfig>('./assets/environment/config.' + envResponse.env + '.json?v=1001').subscribe(responseData => {
                    this.config = responseData as APIHostConfig;
                    this.lender = window.location.hostname.split('.');
                    this.config['lenderId'] = this.lender[0];
                    this.config['host_ror'] = this.config['host_ror'].replace('lenderId', this.lender[0]);
                    this.config['host_factoring'] = this.config['host_factoring'].replace('lenderId', this.lender[0]);
                    this.config['host_mcl'] = this.config['host_mcl'].replace('lenderId', this.lender[0]);
                    this.config['host_cash_application'] = this.config['host_cash_application'].replace('lenderId', this.lender[0]);
                    this.config['host_notification_socket'] = this.config['host_notification_socket'];
                    // CyncConstants.setAssetsPath(this.config[CyncConstants.ASSETS_PATH]);
                    // this.loadLibrariesAtIndexHtml();
                    let config_serialize=JSON.stringify(this.config);
                    localStorage.setItem('config',config_serialize);
                    // console.log(config_serialize);
                    resolve(true);
                   
             }, (error) => {
                    console.error('Error reading ' + tempEnvResponse.env + ' configuration file');
                    reject(error);
             });
             this.cyncCookie = this.cookieService.get('cync_authorization');
        },(error) => {
             console.log('Configuration file "env.json" could not be read');
             this.cyncCookie = this.cookieService.get('cync_authorization');
             if (this.cyncCookie != null && this.cyncCookie != '') this.config['cyncUserCookie'] = this.cyncCookie;
             reject(true);
        }, () => {
            console.log("::Complite Confg::");
        });
    });
}
  /**
   * to check whether we are on local server or not
   */
  public MI_ON_LOCAL_SERVER(): boolean {
    let flag: boolean = false;
    if (this.envName != null || this.envName != undefined)
      flag = this.envName.toLowerCase() === 'local'.toLowerCase();
    return flag;
  }
}
